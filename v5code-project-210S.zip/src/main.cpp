/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\liron                                            */
/*    Created:      Wed Mar 29 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// FL                   motor         13              
// ML                   motor         16              
// BL                   motor         15              
// FR                   motor         17              
// MR                   motor         14              
// BR                   motor         18              
// Roller               motor         9               
// Catapult             motor         10              
// LineTrackerA         line          A               
// expansion            digital_out   B               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

// Start  FrontLeft.startRotateFor(vex::directionType::fwd, 100, vex::rotationUnits::deg);
// End  BackRight.rotateFor(vex::directionType::fwd, 100, vex::rotationUnits::deg);

void autonomous(void) { // AUTON IS HERE change later
/*
  boostpneumatic.set(true);
  boostpneumatic.set(false);

  FrontLeft.startRotateFor(vex::directionType::fwd, 100, vex::rotationUnits::deg);
  MiddleLeft.startRotateFor(vex::directionType::fwd, 100, vex::rotationUnits::deg);
  BackLeft.startRotateFor(vex::directionType::fwd, 100, vex::rotationUnits::deg);
  FrontRight.startRotateFor(vex::directionType::fwd, 100, vex::rotationUnits::deg);
  MiddleRight.startRotateFor(vex::directionType::fwd, 100, vex::rotationUnits::deg);
  BackRight.rotateFor(vex::directionType::fwd, 100, vex::rotationUnits::deg);*/
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) { // User control code here, inside the loop
  while (1) {
    
    //Input from controller
    //Axis3(left joystick up and down) for backwards and forwards movement
    //Axis1(right joystick right and left) for sideways movement

    int leftPower = Controller1.Axis3.position(percent) + Controller1.Axis1.position(percent);
    int rightPower = Controller1.Axis3.position(percent) - Controller1.Axis1.position(percent);

    FL.spin(forward, leftPower, percent);
    ML.spin(forward, leftPower, percent);
    BL.spin(forward, leftPower, percent);
    FR.spin(forward, rightPower, percent);
    MR.spin(forward, rightPower, percent);
    BR.spin(forward, rightPower, percent);

    Brain.Screen.print(LineTrackerA.reflectivity());
    Brain.Screen.newLine();

    if(Controller1.ButtonL1.pressing()) { //forward intake
      Roller.spin(forward, 100, percent);
    }
    else if(Controller1.ButtonL2.pressing()) { //backward intake
      Roller.spin(reverse, 100, percent);
    }
    else if(Controller1.ButtonRight.pressing()) { //slower roller
      Roller.spin(reverse, 30, percent);
    }
    else {
      Roller.stop();
    }
    
    if(Controller1.ButtonR1.pressing() || LineTrackerA.reflectivity() < 60) { //catapult auto and button
      Catapult.spin(forward, 100, percent);
    } 
    else if(LineTrackerA.reflectivity() > 60) {
      Catapult.spinFor(forward, 2, degrees);
    }
    else {
      Catapult.stop();
    }

    if(Controller1.ButtonY.pressing()) { //pneumatic expansion on
      expansion.set(true);
    }
    else if(Controller1.ButtonB.pressing()) { //pneumatic expansion off
      expansion.set(false);
    }
  }
  wait(5, msec); 
}

int main() { // Main will set up the competition functions and callbacks.
  // Set up callbacks for autonomous and driver control periods.
  
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();
  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
